<?php
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php');
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/db.class.php');
	class Autoloader extends Worker {
	    public function __construct($loader) {
	        $this->loader = $loader;
	    }
	    public function run()   { foreach ($this->loader as $loader) { require_once($loader); } }
	    public function start(int $options = PTHREADS_INHERIT_ALL) { return parent::start(PTHREADS_INHERIT_NONE); }
	    protected $loader;
	}



	class download extends Thread {
		private $thread_id;
		private $data;
		private $image_folder;
		public function __construct($thread_id,$data,$image_folder){
			$this->thread_id=$thread_id;
			$this->data=$data;
			$this->image_folder=$image_folder;
		}
		public function run(){
			$uas=[
				'Microsoft SignalR/5.0 (5.0.5; Unknown OS; Browser; Unknown Runtime Version)',
				'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:104.0) Gecko/20100101 Firefox/104.0',
				'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
				'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.102 Safari/537.36 OPR/90.0.4480.84',
				'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
				'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
			];
			$php=new QuyetPHP();
			$guzzle=new GuzzleHttp\Client([
				'headers'=>[
					// 'User-Agent'=>$uas[rand(0,count($uas)-1)]
					'User-Agent'=>'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
				],
				'timeout'=>30
			]);
			foreach ($this->data as $data){
				
				$ex=explode('|',$data);
				
				$manga_title=$ex[0];
				$manga_poster=$ex[1];
				$chapter_title=$ex[2];
				

				$img=$ex[3];
				$source=$ex[4];

				if (!file_exists($this->image_folder.'/'.md5($source))){
					mkdir($this->image_folder.'/'.md5($source),0755);
				}

				if (!file_exists($this->image_folder.'/'.md5($source).'/'.$php->slug($manga_title))){
					@mkdir($this->image_folder.'/'.$source.'/'.$php->slug($manga_title),0755);
				}

				$img_file=$this->image_folder.'/'.md5($source).'/'.$php->slug($manga_title).'/'.$chapter_title.'/'.basename($img);
				if (!file_exists($img_file)){
					try {
						if (!file_exists($this->image_folder.'/'.md5($source).'/'.$php->slug($manga_title).'/'.$chapter_title)){
							@mkdir($this->image_folder.'/'.md5($source).'/'.$php->slug($manga_title).'/'.$chapter_title,0755);
						}
						$t=0;
						$img=str_replace('https://','https://i0.wp.com/',$img);
						retry:
						$guzzle->request('GET',$img,[
							'headers'=>[
								'referer'=>'https://'.$source
							],
							'sink'=>$img_file
						]);
						// $info->success[]=$img;
						file_put_contents(__DIR__ .'/tmp/'.$source.'_download_success.txt', $img.PHP_EOL,FILE_APPEND);
					} catch (Exception $e){
						if ($t<2){
							$t++;
							$img=str_replace('https://i0.wp.com/','https://',$img);
							goto retry;
						} else {
							file_put_contents(__DIR__ .'/tmp/'.$source.'_download_failed.txt', $img.'|'.$e->getCode().PHP_EOL,FILE_APPEND);
						}
						
					}
				}

				
			}
		}

	}

	$source='manhwa18.cc';
	$info=new stdClass;

	$config=parse_ini_file(__DIR__ .'/..'.'/..'.'/..'.'/config.ini',true);

	$wpdb=new wpdb($config['mysql']['username'],$config['mysql']['password'],$config['mysql']['database'],$config['mysql']['host']);
	$result=$wpdb->get_row("SELECT text_value FROM tbl_consts WHERE type='manga' AND value='global'");
	if (!isset($result->text_value)){
		$info->status=false;
		$info->error='Can not get global config';
		$info->failed[0]=0;
		die(json_encode($info));
	}
	$config=json_decode($result->text_value);
	$image_folder=$config->image_folder;
	// die($image_folder);
	
	file_put_contents(__DIR__ .'/tmp/'.$source.'_download_success.txt', null);
	file_put_contents(__DIR__ .'/tmp/'.$source.'_download_failed.txt', null);
	if (!file_exists(__DIR__ .'/tmp/'.$source.'_download_data.txt')){
		$info->status=false;
		$info->error='Empty download data (no url to download)';
		die(json_encode($info));
	}

	$data=array_filter(file(__DIR__ .'/tmp/'.$source.'_download_data.txt',FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
	// echo $data[0];die();

	$classes[]=__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php';
	$classes[]=__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/quyet.class.php';

	$thread_config=parse_ini_file(__DIR__ .'/config.ini',true);
	if (isset($thread_config['global']['download_threads'])){
		$max=$thread_config['global']['download_threads'];
	} else {
		$max=100;
	}

	$total=count($data);
	$ppp=ceil($total/$max);
	if ($max>=$total) { $max=$total; $ppp=1; }

	$start=microtime(true);
	$pool=new Pool($max,Autoloader::class,[$classes]);
	for ($i=0;$i<$max;$i++){
		$pool->submit(new download($i,array_slice($data,$i*$ppp,$ppp),$image_folder));
	}
	$pool->shutdown();


	$info->status=true;
	$info->success=array_filter(file(__DIR__ .'/tmp/'.$source.'_download_success.txt',FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
	$info->failed=array_filter(file(__DIR__ .'/tmp/'.$source.'_download_failed.txt',FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));

	die(json_encode($info));
		

	







