<?php
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php');
	class Autoloader extends Worker {
	    public function __construct($loader) {
	        $this->loader = $loader;
	    }
	    public function run()   { foreach ($this->loader as $loader) { require_once($loader); } }
	    public function start(int $options = PTHREADS_INHERIT_ALL) { return parent::start(PTHREADS_INHERIT_NONE); }
	    protected $loader;
	}


	
	class get_images extends Thread {
		private $thread_id;
		private $urls;
		public function __construct($thread_id,$urls,$source){
			$this->thread_id=$thread_id;
			$this->urls=$urls;
			$this->source=$source;
		}
		public function run(){
			$info=new stdClass;
			$info->status=false;
			$guzzle=new GuzzleHttp\Client([
				'headers'=>[
					'User-Agent'=>'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'
				]
			]);
			foreach ($this->urls as $url){
				// echo $url.PHP_EOL;
				try {
					$resp=$guzzle->request('GET',$url);
					$content=$resp->getBody()->getContents();
					// file_put_contents(__DIR__ .'/test.html', $content);
					preg_match('/<div class="read-content(.*?)>(.*?)<\/div>/is',$content,$m);
					preg_match_all('/<img(.*?)src=\'(.*?)\'(.*?)>/is',$m[2],$match);
					// file_put_contents(__DIR__ .'/test.txt', print_r($match[2],true));
					for ($i=0;$i<count($match[2]);$i++){
						file_put_contents(__DIR__ .'/tmp/'.$this->source.'/'.base64_encode($url).'.txt', trim(str_replace("\t",'',$match[2][$i])).PHP_EOL,FILE_APPEND);
					}


					
				} catch (GuzzleHttp\Exception\ConnectException $e){
					$info->status_code=$e->getCode();
					$info->error='ConnectException';
				} catch (GuzzleHttp\Exception\RequestException $e){
					$info->status_code=$e->getCode();
					$info->error='RequestException';
				} catch (Exception $e){
					$info->status_code=9;
					$info->error='UnknownException';
				}
			}
		}

	}

	$source='manhwa18.cc';
	if (!file_exists(__DIR__ .'/tmp/'.$source)){
		@mkdir(__DIR__ .'/tmp/'.$source,0755);
	}

	$urls=json_decode(base64_decode($argv[1]));
	// print_r($urls);
	$total=count($urls);
	$max=50;
	$ppp=ceil($total/$max);
	if ($max>=$total) { $max=$total; $ppp=1; }

	$start=microtime(true);
	$pool=new Pool($max,Autoloader::class,[[
		__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php'
	]]);
	for ($i=0;$i<$max;$i++){
		// echo "\033[37m\033[1mSubmit thread $i\033[0m".PHP_EOL;
		$pool->submit(new get_images($i,array_slice($urls,$i*$ppp,$ppp),$source));
	}
	$pool->shutdown();

	foreach ($urls as $url){
		$images[$url]=array_filter(file(__DIR__ .'/tmp/'.$source.'/'.base64_encode($url).'.txt',FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
		unlink(__DIR__ .'/tmp/'.$source.'/'.base64_encode($url).'.txt');
	}
	
	echo base64_encode(json_encode($images));





