<?php
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php');
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/quyet.class.php');
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/db.class.php');
	class Autoloader extends Worker {
	    public function __construct($loader) {
	        $this->loader = $loader;
	    }
	    public function run()   { foreach ($this->loader as $loader) { require_once($loader); } }
	    public function start(int $options = PTHREADS_INHERIT_ALL) { return parent::start(PTHREADS_INHERIT_NONE); }
	    protected $loader;
	}



	class leech_info extends Thread {
		private $thread_id;
		private $data;
		private $image_folder;
		public function __construct($thread_id,$data,$image_folder){
			$this->thread_id=$thread_id;
			$this->data=$data;
			$this->image_folder=$image_folder;
		}
		public function run(){
			$php=new QuyetPHP();
			$guzzle=new GuzzleHttp\Client();
			foreach ($this->data as $url=>$source){
				$class=str_replace('.','_',$source);
				$manga=new $class();
				$info=$manga->get_info($url);
				if (!file_exists($this->image_folder.'/'.md5($source).'/'.$php->slug($info->title))){
					@mkdir($this->image_folder.'/'.md5($source).'/'.$php->slug($info->title),0755);
				}

				$poster=$this->image_folder.'/'.md5($source).'/'.$php->slug($info->title).'/poster.jpg';

				try {
					$t=0;
					retry:
					$guzzle->request('GET',$info->poster,[
						'headers'=>[
							'referer'=>'https://'.$source
						],
						'sink'=>$poster
					]);
				} catch (Exception $e){
					if ($t<2){
						$t++;
						goto retry;
					}
				}
				$info->source=$source;
				$info->poster=$poster;
				file_put_contents(__DIR__ .'/tmp/'.base64_encode($url).'.txt', base64_encode(json_encode($info)));
			}
		}

	}








	$config=parse_ini_file(__DIR__ .'/..'.'/..'.'/..'.'/config.ini',true);
	$wpdb=new wpdb($config['mysql']['username'],$config['mysql']['password'],$config['mysql']['database'],$config['mysql']['host']);
	$result=$wpdb->get_row("SELECT text_value FROM tbl_consts WHERE type='manga' AND value='global'");
	if (!isset($result->text_value)){
		$info->status=false;
		$info->error='Can not get global config';
		$info->failed[0]=0;
		die(json_encode($info));
	}
	$config=json_decode($result->text_value);
	$image_folder=$config->image_folder;

	$data=json_decode(base64_decode($argv[1]),true);
	
	foreach ($data as $url=>$source){
		$sources[]=$source;
	}
	$sources=array_unique($sources);
	foreach ($sources as $source){
		$classes[]=__DIR__ .'/'.$source.'.class.php';
	}
	$classes[]=__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php';
	$classes[]=__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/quyet.class.php';


	$thread_config=parse_ini_file(__DIR__ .'/config.ini',true);
	if (isset($thread_config['global']['leech_threads'])){
		$max=$thread_config['global']['leech_threads'];
	} else {
		$max=3;
	}


	$total=count($data);
	$ppp=ceil($total/$max);
	if ($max>=$total) { $max=$total; $ppp=1; }

	$start=microtime(true);
	$pool=new Pool($max,Autoloader::class,[$classes]);
	for ($i=0;$i<$max;$i++){
		$pool->submit(new leech_info($i,array_slice($data,$i*$ppp,$ppp),$image_folder));
	}
	$pool->shutdown();

	foreach ($data as $url=>$source){
		if (file_exists(__DIR__ .'/tmp/'.base64_encode($url).'.txt')){
			$resp[$url]=json_decode(base64_decode(file_get_contents(__DIR__ .'/tmp/'.base64_encode($url).'.txt')));
			unlink(__DIR__ .'/tmp/'.base64_encode($url).'.txt');
		}
	}

	echo base64_encode(json_encode($resp));

	

	







