<?php
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php');
	require_once(__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/quyet.class.php');
	class Autoloader extends Worker {
	    public function __construct($loader) {
	        $this->loader = $loader;
	    }
	    public function run()   { foreach ($this->loader as $loader) { require_once($loader); } }
	    public function start(int $options = PTHREADS_INHERIT_ALL) { return parent::start(PTHREADS_INHERIT_NONE); }
	    protected $loader;
	}



	class manhwa_get_info extends Thread {
		private $thread_id;
		private $urls;
		public function __construct($thread_id,$urls){
			$this->thread_id=$thread_id;
			$this->urls=$urls;
		}
		public function run(){
			$uas=[
				'Microsoft SignalR/5.0 (5.0.5; Unknown OS; Browser; Unknown Runtime Version)',
				'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:104.0) Gecko/20100101 Firefox/104.0',
				'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
				'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.102 Safari/537.36 OPR/90.0.4480.84',
				'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
				'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
			];
			$php=new QuyetPHP();
			
			foreach ($this->urls as $url){
				// echo $url.PHP_EOL;
				$info=$this->get_info($url,false);
				if ($info->status){
					file_put_contents(__DIR__ .'/tmp/info_cli_success.txt', base64_encode(json_encode($info)).PHP_EOL,FILE_APPEND);
				} else {
					file_put_contents(__DIR__ .'/tmp/info_cli_failed.txt', base64_encode(json_encode($info)).PHP_EOL,FILE_APPEND);
				}
			}
		}


		public function get_info($url,$fetch_all=true){
			$guzzle=new GuzzleHttp\Client([
				'headers'=>[
					// 'User-Agent'=>$uas[rand(0,count($uas)-1)]
					'User-Agent'=>'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
				],
				'timeout'=>30
			]);
			// $php=new QuyetPHP();
			$info=new stdClass;
			$info->status=false;
			try {
				$resp=$guzzle->request('GET',$url);
				$content=$resp->getBody()->getContents();
				$info->status=true;
				$info->source_url=$url;
				
				preg_match('/<h1(.*?)>(.*?)<\/h1>/is',$content,$match);
				if (!isset($match[2])){
					$info->status=false;
					$info->error='Empty title';
				} else {
					$info->title=trim(preg_replace('/<span(.*?)>(.*?)<\/span>(.*)/is','$3',$match[2]));
					preg_match('/"manga_id"\:"(.*?)"/is',$content,$match);
					$info->source_id=0;
					if (isset($match[1])){
						$info->source_id=$match[1];
					}
					
					$info->poster='';
					preg_match('/og\:image" content="(.*?)"/is',$content,$match);
					if (isset($match[1])){
						$info->poster=$match[1];
					}

					$info->content='';
					preg_match('/<div class="dsct">(.*?)<\/div>/is',$content,$match);
					if (isset($match[1])){
						$info->content=trim(strip_tags($match[1],''));
					}
					$info->genres=[];
					preg_match('/<div class="genres-content">(.*?)<\/div>/is',$content,$m);
					preg_match_all('/<a(.*?)>(.*?)<\/a>/is',$m[1],$match);
					if (isset($match[2])){
						for ($i=0;$i<count($match[2]);$i++){
							$info->genres[]=trim($match[2][$i]);
						}
					}

					$info->rating=0;
					preg_match('/id="averagerate">(.*?)<\/span>/is',$content,$match);
					if (isset($match[1])){
						$info->rating=$match[1];
					}

					$info->rating_count=0;
					preg_match('/id="countrate">(.*?)<\/span>/is',$content,$match);
					if (isset($match[1])){
						$info->rating_count=$match[1];
					}

					$info->release='';
					preg_match('/<h5>(.*?)Release(.*?)<\/h5>(.*?)<div class="summary-content"(.*?)>(.*?)<\/div>/is',$content,$match);
					// print_r($match);
					if (isset($match[5])){
						$info->release=(int)trim($match[5]);
					}

					$info->manga_status='';
					preg_match('/<h5>(.*?)Release(.*?)<h5>(.*?)Status(.*?)<\/h5>(.*?)<div class="summary-content"(.*?)>(.*?)<\/div>/is',$content,$match);
					// print_r($match);
					if (isset($match[7])){
						$info->manga_status=strtolower(trim($match[7]));
					}

					$info->alternative='';
					preg_match('/<h5>(.*?)Alternative(.*?)<\/h5>(.*?)<div class="summary-content">(.*?)<\/div>/is',$content,$match);
					if (isset($match[4])){
						$info->alternative=trim($match[4]);
					}

					$info->authors=[];
					preg_match('/<h5>(.*?)Author\(s\)(.*?)<\/h5>(.*?)<div class="summary-content">(.*?)<\/div>/is',$content,$match);
					if (isset($match[4])){
						preg_match_all('/<a(.*?)>(.*?)<\/a>/is',$match[4],$m);
						if (isset($m[2])){
							for ($i=0;$i<count($m[2]);$i++){
								$info->authors[]=trim($m[2][$i]);
							}
						}
					}
					

					$info->artists=[];
					preg_match('/<h5>(.*?)Artist\(s\)(.*?)<\/h5>(.*?)<div class="summary-content">(.*?)<\/div>/is',$content,$match);
					if (isset($match[4])){
						preg_match_all('/<a(.*?)>(.*?)<\/a>/is',$match[4],$m);
						if (isset($m[2])){
							for ($i=0;$i<count($m[2]);$i++){
								$info->artists[]=trim($m[2][$i]);
							}
						}
					}

					$info->manga_type='';
					preg_match('/<h5>(.*?)Type(.*?)<\/h5>(.*?)<div class="summary-content">(.*?)<\/div>/s',$content,$match);
					// print_r($match);
					if (isset($match[4])){
						$info->manga_type=trim($match[4]);
					}

					//chapters
					
					$info->chapters=[];
					$urls=[];
					try {
						preg_match('/<ul class="row-content-chapter(.*?)>(.*?)<\/ul>/is',$content,$m);
						preg_match_all('/<li(.*?)href="(.*?)"(.*?)>(.*?)<\/a>(.*?)(<span class="chapter-time(.*?)>(.*?)<\/span>|<img(.*?)>(.*?)<\/li>)/is',$m[2],$match);
						if (isset($match[2])){
							for ($i=0;$i<count($match[2]);$i++){
								$info->chapters[$i]=new stdClass;
								$info->chapters[$i]->title=trim($match[4][$i]);
								$info->chapters[$i]->url='https://manhwa18.cc'.$match[2][$i];
								if (trim($match[8][$i])==''){
									preg_match('/"dateModified"\:"(.*?)"/is',$content,$mm);
									$info->chapters[$i]->update=date('Y-m-d',strtotime($mm[1]));
								} else {
									$info->chapters[$i]->update=date('Y-m-d',strtotime(trim($match[8][$i])));
								}
								$urls[]='https://manhwa18.cc'.$match[2][$i];
							}
						}
						
						if ($fetch_all){
							//Get all images of chapters
							$cmd='phpz '.__DIR__ .'/manhwa18.cc_cli.php manhwa18.cc "'.base64_encode(json_encode($urls)).'"';
							// echo $cmd;
							$out=shell_exec($cmd);
							// echo $out;die();
							$json=json_decode(base64_decode($out),true);
							// print_r($json);die();
							// $json=json_decode(base64_decode(file_get_contents(__DIR__ .'/tmp/manhwa.txt')),true);
							
							$info->total_images=0;
							foreach ($info->chapters as $key=>$chapter){
								try {
									$info->chapters[$key]->images=array_values(array_filter($json[$chapter->url]));
									$info->total_images+=count($info->chapters[$key]->images);
								} catch (Exception $e){
									file_put_contents(__DIR__ .'/log_error.txt', $url.PHP_EOL,FILE_APPEND);
								}
							}
						}
						
						
					} catch (Exception $e){

					}
				}
			} catch (GuzzleHttp\Exception\ConnectException $e){
				$info->status_code=$e->getCode();
				$info->error='ConnectException';
			} catch (GuzzleHttp\Exception\RequestException $e){
				$info->status_code=$e->getCode();
				$info->error='RequestException';
			} catch (Exception $e){
				$info->status_code=9;
				$info->error='UnknownException';
			}
			return $info;
		}
	}

	file_put_contents(__DIR__ .'/tmp/info_cli_success.txt', null);
	file_put_contents(__DIR__ .'/tmp/info_cli_failed.txt', null);
	$urls=json_decode(base64_decode($argv[1]));
	

	$thread_config=parse_ini_file(__DIR__ .'/config.ini',true);
	if (isset($thread_config['global']['get_info_threads'])){
		$max=$thread_config['global']['get_info_threads'];
	} else {
		$max=50;
	}


	$total=count($urls);
	$ppp=ceil($total/$max);
	if ($max>=$total) { $max=$total; $ppp=1; }
	// echo $ppp;die();
	$classes=[
		__DIR__ .'/..'.'/..'.'/..'.'/lib/qclass/quyet.class.php',
		__DIR__ .'/..'.'/..'.'/..'.'/lib/guzzle/vendor/autoload.php',
	];
	$start=microtime(true);
	$pool=new Pool($max,Autoloader::class,[$classes]);
	for ($i=0;$i<$max;$i++){
		$pool->submit(new manhwa_get_info($i,array_slice($urls,$i*$ppp,$ppp)));
	}
	$pool->shutdown();

	$php=new QuyetPHP();

	$_successes=array_filter(file(__DIR__ .'/tmp/info_cli_success.txt',FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
	// echo count($_successes);die();
	// print_r($_successes);die();
	foreach ($_successes as $_success){
		// echo $_success;die();
		$_success=json_decode(base64_decode($_success));
		$success[$_success->source_url]=count($_success->chapters).'|'.$_success->rating;
	}
	
	// print_r($success);

	$info=new stdClass;
	$info->status=true;
	$info->data=$success;

	die(base64_encode(json_encode($info)));
		

	







