<?php
/**
 * @package Madara_patch
 * @version 1.0
 */
/*
Plugin Name: Madara Patch
Plugin URI: https://nhq.tools
Description: Allow sepcial madara taxonomy
Author: Nguyen Huu Quyet
Version: 1.0
Author URI: https://nhq.tools
*/
function nhq_unprotect_meta( $protected, $meta_key, $meta_type ) {

    if( '_wp_manga_alternative' == $meta_key || '_wp_manga_chapter_type' == $meta_key || '_wp_manga_type' == $meta_key || '_wp_manga_views' == $meta_key || '_wp_manga_status' == $meta_key || '_manga_avarage_reviews' == $meta_key || '_wp_manga_month_views_value'==$meta_key || '_manga_reviews' == $meta_key) {
    	return false;
    }

}
add_filter( 'is_protected_meta', 'nhq_unprotect_meta', 10, 3 );